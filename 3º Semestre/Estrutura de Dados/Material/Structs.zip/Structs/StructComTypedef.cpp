#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<locale.h>


//criando estruturas com o typedef
typedef struct pessoa {
    int codigo;
    char nome[30];
};

int main (){
    setlocale(LC_ALL, "");

    pessoa joao;

    printf ("Digite o c�digo da pessoa: ");
    scanf ("%d", &joao.codigo);
    printf ("\nDigite o nome da pessoa: ");
    scanf ("%s", &joao.nome);

    printf ("\n\n\nO c�digo da pessoa �: %d\n", joao.codigo);
    printf ("O nome da pessoa � %s\n\n\n", joao.nome);

}
