#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<locale.h>


using namespace std;

//criando uma estrutura como uma vari�vel

int main()
{
    struct {
        int codigo;
        char nome[30];
    }pessoa;

    setlocale(LC_ALL, "");
    printf ("Digite o c�digo da pessoa: ");
    scanf ("%d", &pessoa.codigo);
    printf ("\nDigite o nome da pessoa: ");
    scanf ("%s", &pessoa.nome);


    printf ("\n\n\n\nO c�digo da pessoa �: %d", pessoa.codigo);
    printf ("\nO nome da pessoa �: %s", pessoa.nome);




    return 0;
}




