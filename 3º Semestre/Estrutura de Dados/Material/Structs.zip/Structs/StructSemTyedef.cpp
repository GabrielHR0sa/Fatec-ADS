#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<locale.h>




//Criando uma estrutura como um tipo de dado a ser usado pela ferramenta sem o typedef

struct pessoa{
        int codigo;
        char nome;
    };

int main ()
{


    struct pessoa joao[5];

    setlocale(LC_ALL, "");

    printf ("Digite o c�digo da pessoa: ");
    scanf ("%d", &joao.codigo);
    printf ("\nDigite o nome da pessoa: ");
    scanf ("%s", &joao.nome);

    printf ("\n\n\nO c�digo da pessoa �: %d", joao.codigo);
    printf ("\nO nome da pessoa �: %s", joao.nome);


    return 0;
}

