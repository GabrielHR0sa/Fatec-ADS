#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<locale.h>


using namespace std;

//criando uma estrutura como uma vari�vel
/*
int main()
{
    struct {
        int codigo;
    }pessoa;

    setlocale(LC_ALL, "");
    scanf ("%d", &pessoa.codigo);

    printf ("O c�digo da pessoa �: %d", pessoa.codigo);


    return 0;
}


//Criando uma estrutura como um tipo de dado a ser usado pela ferramenta sem o typedef
/*
struct pessoa{
        int codigo;
    };
int main ()
{


    struct pessoa joao;

    setlocale(LC_ALL, "");
    scanf ("%d", &joao.codigo);

    printf ("O c�digo da pessoa �: %d", joao.codigo);


    return 0;
}

*/

//criando estruturas com o typedef
typedef struct pessoa {
    int codigo;
    char nome[30];
};

int main (){
    setlocale(LC_ALL, "");
    pessoa joao;

    printf ("Digite o c�digo da pessoa: ");
    scanf ("%d", &joao.codigo);
    printf ("\nO c�digo da pessoa �: %d\n", joao.codigo);
    printf ("\nDigite o nome da pessoa: ");
    scanf ("%s", &joao.nome);
    printf ("O nome da pessoa � %s", joao.nome);

}
